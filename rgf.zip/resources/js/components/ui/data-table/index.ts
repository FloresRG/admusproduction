// resources/js/components/ui/data-table/index.ts
export { DataTable } from "./data-table"
export type { DataTableProps, DataTableColumn } from "./data-table"
